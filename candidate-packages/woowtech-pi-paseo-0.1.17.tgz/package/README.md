# Agent Connect

Connect Pi Agent / Pi Web to **Woowtech Smart**, **Apporo Smart**, or **Paseo** from the package settings. Existing installations keep Paseo selected. The installed package remains `@woowtech/pi-paseo`, with its existing command, tool IDs, routes and data directory.

Changing the target saves its app URL and relay together. If the daemon is running, finish any conversations, disable the connector, then enable it to apply the change. Target changes clear previous pairing and relay verification; generate a fresh pairing link after restarting. Saving only a display name does not restart the daemon. A target change does not revoke a device already paired with the daemon.

| Target | Web app | Relay |
| --- | --- | --- |
| Woowtech Smart | https://smart.woowtech.io | relay.woowtech.io:443 |
| Apporo Smart | https://smart.apporo.ai | relay.apporo.ai:443 |
| Paseo | bundled `/paseo-web` client | relay.paseo.sh:443 |

The connector uses upstream Paseo 0.11.2 and its V2 pairing format. Smart mobile push notifications use a fork-specific FCM protocol and are not supported by this configuration-only integration; desktop/mobile production pairing still needs live acceptance. The branded app source currently identifies itself as 0.10.1.


Pi Agent / Pi Web 插件，管理共用 Paseo 執行環境，沿用 Claude Code、Codex、Pi 的現有登入、工作目錄及權限。使用者在 **Pi Web 設定 → 插件 → Agent Connect** 選擇連線標的並開始配對。

各標的使用自己的加密 relay；從 Pi Web 的受保護設定頁產生配對連結，再開啟所選標的。Paseo 的內建網頁由 Pi Web 既有登入保護；品牌網頁會在各自官方網站開啟。

`v0.1.9` 由插件下載並管理已修補的 Paseo Web 0.13.0，透過 Pi Web 同一網址的 `/paseo-web` 開啟。固定發布包須通過 SHA-256 與來源版本驗證，完成後才切換；登入保護、provider 登入及官方加密 relay 沿用現有設定。修補包含回覆途中重新整理的重複顯示與長回覆截斷；官方 `app.paseo.sh` 的部署進度另見[修補報告](docs/pi4-stream-reload-2026-10-26.md)。

## 0.1.10 PID 復原修補

此歷史修補的 managed runtime revision 為 `0.11.2-r3-6d8dbe515479`，沿用 0.11.2 的固定依賴，額外驗證並修補兩份官方 PID writer。Linux 下，健康啟動或採用後會記錄私有程序出生證明；若同一核心重用了 PID，只在原 installation、home、PID lock 與 boot/start identity 都能證明舊程序已消失時，才隔離自己的過期 PID record 並重新啟動。外來程序不會被終止；設定、登入、資料庫、配對及初始化對話保留。

這項自動復原需要此前成功啟動時建立的 proof。舊版沒有可信 proof 的陌生 PID 仍回報 `DAEMON_NOT_OWNED`，不會自動清檔。仍健康運作的 r2 daemon 會回報 `RESTART_REQUIRED`；正常停止後再啟用即可建立 r3 proof，無須移除私人資料。

`linux-flock-v1` 共同鎖涵蓋這份 r3 runtime 兩個官方模組的 acquire、refresh、update、release，包括直接使用該 runtime 的 CLI。獨立安裝的舊版 CLI 或任意同 UID 程式不受此協定保護，不能與本插件共用其私有 `PASEO_HOME`。未知或不完整的 runtime patch、缺少協定標記、不安全檔案與另一個存活 supervisor 都會停止復原。不要刪除持久的 `.pi-paseo-pid-transition.guard`；它是所有 writer 共用的鎖 inode。

已完成 UID1000 隔離環境的實際 daemon 啟動、配對、受控 receipt 復原、r2 遷移及並行冷啟動驗證，沒有模型呼叫或 live fleet 變動。這不是強制核心 PID 重用／OOM 或最終發行映像的驗收；範圍見[驗證紀錄](docs/validation.md)。

## 相容版本

- Node.js 22.19.0+、npm、git。Linux（包含 Windows 既有 WSL2、Ubuntu、k3s/PaaS、HA add-on）需要 util-linux `flock`；macOS 使用 Node SQLite 交易鎖。原生 Windows 不在本次範圍。各平台的真實部署與 provider 驗收須分別記錄，不能由來源測試推定通過。
- Pi `@earendil-works/pi-coding-agent` 1.0.0+。
- Pi Web 0.10.0，整合層固定基底 commit `6fcd7d44981ab51a21d6cd6eb06d361d0e3d3068`。
- Paseo `@getpaseo/cli` 0.11.2，使用發行包內固定的修補依賴 lockfile，下載至持久 HOME 的獨立版本目錄。
- 受管理的網頁包另需 `tar`；下載約 11 MB，固定版本與校驗值記錄於 `runtime/web-client.json`。
- 登入在執行 Pi Web 的同一使用者 HOME。插件沿用現有 provider CLI；缺少時下載固定版本到插件的獨立目錄。既有帳號資料用於官方 CLI 登入。

啟用本機聽寫或語音模式時，服務的 PATH 還需要 `tar` 與 `bzip2`，並預留語音模型下載、解壓縮與執行所需空間。Paseo 會自動下載缺少的模型；精簡容器沒有 `bzip2` 時，可能已下載完整壓縮檔卻回報 `tar exited with code 2`。容器映像應安裝此相依套件，或使用服務啟動時可找到的持久化工具；只在暫時容器層安裝，重建後會消失。本插件不會替容器安裝 OS 套件。Pi4 的實測與恢復紀錄見 [儲存復原驗證](docs/pi4-storage-recovery-2026-10-25.md)。

## 完整安裝

此 repo 已公開，下載不需要 GitHub 帳號或 token。

在 Pi Web 的 **設定 → 插件 → 安裝** 貼上：

```text
https://github.com/WOOWTECH/pi-paseo-plugin
```

舊版正式部署範例為 `git:github.com/WOOWTECH/pi-paseo-plugin@v0.1.16`。部署新版 Agent Connect 時，請固定已發布的正式標籤，或使用核對過來源與 SHA256 的候選套件；不要假設候選版本已發布。若同一 Pi Web 也安裝 Omnigent，兩個套件的共用介面必須使用同時驗證過的 adapter 版本與 SHA-256，再重新啟動 Pi Web。配對只在 **設定 → 插件 → Agent Connect** 執行。各版本的實測範圍請參考驗證紀錄。

或在 Pi Web 使用者的終端直接執行：

```bash
pi install https://github.com/WOOWTECH/pi-paseo-plugin
```

Git 安裝會下載依賴並執行 postinstall。首次安裝準備完成後，依下面的啟動入口說明重新啟動 Pi Web，即可在 Agent Connect 設定中選擇並連接目標平台。

在 Pi Web 使用者的持久化 HOME 執行：

```bash
git clone https://github.com/WOOWTECH/pi-paseo-plugin.git
cd pi-paseo-plugin
bash scripts/install.sh --source "$PWD"
```

安裝器從目前 checkout 的完整 commit SHA 建立持久化副本，以 lockfile 安裝依賴，註冊 Pi package，套用經 SHA-256 校驗的 Pi Web 補丁並建置正式整合層，再啟動 Paseo。建置使用兩個 Next.js worker。已安裝相同版本時沿用既有建置；更新保留使用者手動停止的狀態。建置失敗保留舊版本及原有入口。

Pi Web 本身需要重新啟動一次才能載入新的整合層。安裝器只準備下一次啟動的入口並回報 `restartRequired`；請透過原服務管理方式重新啟動。原容器以 PATH 呼叫 `pi-web` 時可使用持久化 launcher；已有 shared-runtime 或 Omnigent 啟動器時沿用其原始呼叫鏈。若回報 `manual-routing-required`，請將現有 launcher 的 Pi Web 終端入口接到回報的 `pendingRestart` 路徑。

從 Pi Web 插件頁安裝 npm 發行包時，postinstall 同樣下載 Paseo、準備 Pi Web 整合層並啟動服務。插件頁在首次加入整合層後，需要重新啟動 Pi Web 才能顯示設定頁內的 Agent Connect 控制項。

若回報 `pathUpdateRequired: true`，將回報的 `launcherDirectory` 放到服務啟動環境的 PATH 最前方，再重新啟動。Kubernetes 容器需設定工作負載的 PATH，終端中的 `export PATH=...` 只作用於該次終端。

第一次載入整合層後，在 **設定 → 插件** 選擇 Agent Connect。安裝、啟用及 Pi Web 重啟會啟動／恢復服務，不會建立對話或自動開啟品牌網站。舊的 `/paseo/setup` 連結會導向插件設定；停用／移除只停止插件擁有的程序，保留既有對話、provider 登入及 Paseo 資料。

## 設定與配對

1. 到 **設定 → 插件 → Agent Connect**，選擇 **Woowtech Smart／Apporo Smart／Paseo** 並儲存。若服務正在執行，先結束使用中的回合，再停止並啟動服務，確認新標的已套用。每台主機一次連接一個標的。
2. 缺少或過期的登入，使用 `claude auth login`、`codex login` 或 Pi 的 `/login`。密碼、API Key 與 OAuth 資訊只在官方登入介面或 Pi Web 模型設定輸入。
3. 確認服務已就緒，按 **產生配對連結**，再用顯示所選平台名稱的按鈕開啟網站並確認配對。Paseo 選項使用同一 Pi Web 網址的 `/paseo-web/`，另需內建網頁準備完成；兩個 Smart 選項開啟各自官方網站。切換網站需在新網站配對，Claude／Codex／Pi 的主機登入沿用。
4. 在所選網站選擇這台主機、Claude Code／Codex／Pi、可用模型、模式及思考等級，再建立對話。

模型目錄由 Paseo 動態取得，插件不硬編模型、不強制完整權限。設定頁分別顯示程序啟動、服務可達、relay 歷史驗證與真正對話驗證；帳號額度耗盡會顯示對話限制。

### 顯示名稱

設定頁的名稱是 Pi Web 插件的顯示標籤，可使用大小寫、中文及空白，長度上限 100 字元；空白名稱會使用 `Pi Agent`。儲存標籤不會啟停服務或重新驗證帳號。Paseo 0.11.2 的 daemon 設定不支援 `name`／`displayName`：官方 Web 初始名稱來自容器 hostname，改名則儲存在 Paseo 客戶端。需要變更官方 Web 顯示名稱時，請在該介面重新命名 host；插件不宣稱已同步此名稱。既有插件名稱偏好會保留，重新啟動會移除過去錯誤注入的 `daemon.name`，避免 `CONFIG_INVALID`。

### 沿用 Omnigent 選定的 Claude gateway

若同一使用者的 `~/.omnigent/config.yaml`（或 `OMNIGENT_CONFIG_HOME/config.yaml`）已將 Anthropic 預設 provider 設為 `kind: gateway`，插件啟動／恢復服務時會沿用該選擇。這項整合需要 PATH 中可用的 Omnigent 與其 Python 環境，以及 `anthropic.auth_command`、`anthropic.models.default`；模型清單只列出該設定宣告的實際模型，會展開 tier 別名並合併重複項目。它沿用既有 gateway 授權，不表示 Claude 官方訂閱已登入。

驗證命令由 Claude 的 invocation-local `apiKeyHelper` 按需執行，最長快取 15 分鐘；插件不把命令或產生的憑證寫入 Paseo 設定、啟動檔或日誌，也不修改 Omnigent 設定與官方登入檔。插件私有目錄內的 `0700` 啟動檔只存路徑與設定指紋，讓 Paseo 的 Claude SDK 能用單一執行檔啟動。驗證命令的輸出上限為 4 KB、逾時為 20 秒，失敗只回報固定錯誤碼。

在 Omnigent 切回官方 Claude provider 後，於 Agent Connect 設定按「啟動服務」會恢復原本的 Claude 執行檔與模型設定。變更 gateway、模型或驗證命令後也要執行此操作，再建立新的對話；舊設定指紋會被拒絕，避免沿用錯誤路由。此整合僅支援既有 `auth_command` 型 gateway 與 HTTPS（本機 loopback 可用 HTTP）；inline key、secret reference、其他 provider 類型不在此自動橋接範圍。gateway 缺少必要設定時會標示不可用，不會改用另一個帳號。

從 gateway 改用 Claude 官方訂閱時，先在 Pi Web 相同 HOME 執行 `claude auth login --claudeai`，完成[官方瀏覽器授權](https://code.claude.com/docs/en/authentication)，再將 Omnigent 的 **Anthropic 預設來源**選為 Claude 訂閱並於 Agent Connect 設定啟動服務。只完成 CLI 登入，不會覆蓋仍被選用的 gateway。切換時保留 OpenAI 與 Pi 的預設來源；官方登入資料由 Claude CLI 管理，不應貼入 Paseo 或 Omnigent 的設定檔。Pi4 的切換、重啟及實測範圍見[官方訂閱驗證](docs/pi4-official-subscription-2026-10-26.md)。

### 選用 Omnigent gateway 作為 Codex 模型來源

有 OpenAI Responses 相容 Omnigent 路由的部署，可參考[通用封裝範例](examples/omnigent-codex-gateway.py)，用 Paseo [自訂 provider](https://paseo.sh/docs/custom-providers) 的 `extends: "codex"`、`command`、`env` 和 `models` 建立獨立選項。範例需要 Python YAML 套件，以及 `PI_PASEO_OMNIGENT_CONFIG`、`PI_PASEO_OMNIGENT_PROVIDER`、`PI_PASEO_CODEX_BINARY`；可用 `PI_PASEO_CODEX_HOME` 指定私有 Codex home。範例每次啟動從受保護的 Omnigent 設定執行既有 `pi auth print-api-key` 命令，把憑證放在 Codex 子程序環境，專用 `config.toml` 只寫入路由和模型。部署者須保護設定檔與工作目錄，並在變更後執行 `paseo --home /path/to/paseo-home daemon reload`，指定這個插件管理的 daemon home。

Codex 的 gateway 仍須另外設定；標準安裝不會更改內建 `codex` provider 的登入。自訂路由的可用性應以該路由的實際對話驗收；它不代表 OpenAI 官方帳號已登入。Codex [自訂模型提供者設定](https://learn.chatgpt.com/docs/config-file/config-advanced) 說明協定和憑證環境變數。

### 官方 Codex 與 gateway 的設定隔離

若官方登入成功，內建 Codex 的模型清單卻只有 gateway 模型，請檢查它實際使用的 `CODEX_HOME/config.toml`。其他整合工具可能在共用設定加入 `model_catalog_json`，導致登入有效、模型目錄卻指向另一條路由。2026-10-25 的實機驗收曾重現並解決此情況。

需要兩種來源並存時，為官方 Codex 建立獨立的私有目錄，並將下列 `env` 合併到既有 Paseo 設定；保留其他 provider 及設定：

```json
{
  "agents": {
    "providers": {
      "codex": {
        "env": { "CODEX_HOME": "/path/to/private/paseo-codex-home" }
      }
    }
  }
}
```

目錄權限使用 `0700`、憑證檔使用 `0600`。在同一執行使用者下，以相同 `CODEX_HOME` 和 provider 的官方 CLI 完成 `codex login --device-auth`；後續重新登入也必須使用這個目錄。若共用啟動器會改寫模型設定，登入時使用 provider `command` 指定的原始官方執行檔。此目錄不應沿用 gateway 的 `model_catalog_json` 或路由設定。完成後重載指定 daemon，重新讀取模型並執行兩輪驗收；官方 Codex 與自訂 gateway 都應各自驗證。

## Pi 操作

- **Pi Web 設定 → 插件 → Agent Connect**：唯一的配對與整合設定入口。
- `paseo_status`、`paseo_diagnose`、`paseo_models`：無秘密的狀態及模型探測。
- `paseo_chat`、`paseo_continue`：建立與續接 Paseo 對話。

Shell 操作：

```bash
node bin/cli.mjs status
node bin/cli.mjs health
node bin/cli.mjs diagnose
node bin/cli.mjs models codex
node bin/cli.mjs start
node bin/cli.mjs stop
```

`node bin/cli.mjs acceptance` 會對三種 provider 各發送兩則小型驗收訊息，使用現有帳號額度。驗收完成後自動歸檔此次測試對話，保留紀錄並釋放 provider 程序；清理失敗也會使整體驗收失敗。CLI 配對僅在私人終端用 `pair --reveal`；一般使用者應使用設定頁，配對連結不應進入聊天、Git 或一般日誌。

## 資料與生命週期

預設狀態放在 `$PI_CODING_AGENT_DIR/pi-paseo/`，未設定時使用 `~/.pi/agent/pi-paseo/`；Paseo 自有 home 位於該狀態目錄的 `daemon/`。runtime 使用 lockfile 雜湊識別獨立版本，不覆寫正在使用的舊依賴；更新後若 daemon 尚在使用舊版本，需停止後啟動或透過既有容器服務重啟。套件與整合層放在 `~/.local/share/pi-paseo/`。provider 的 HOME 和 Pi data directory 沿用原環境。

daemon 預設只監聽 loopback 的 6769 埠，埠被占用時選擇其他可用埠。relay 配對不需要對外開啟容器埠。背景 supervisor 每 15 秒只讀 PID 鎖與 `/proc` 的程序 metadata，故障時恢復插件服務；它不向 daemon 查狀態，因為 Paseo 每回答一次狀態查詢，就對每個啟用的 provider 執行一次 `--version`（4 核 H618 上，原本的 15 秒輪詢約佔閒置 CPU 的六成）。這不會週期性呼叫模型。Pi 的 `models.json` 或 `settings.json` 在 daemon 建好 Pi 模型清單之後有變動時，supervisor 會請 daemon 重建一次 Pi 清單（每次變動只試一次，失敗也不重試）；`models pi` 讀取前也做同樣的檢查。Pi Web 整合層在重啟後恢復 supervisor。

`state.json` 僅保存白名單狀態；配對資訊放在 mode 0600 的專用檔案，設定頁回應使用 `no-store`。舊版、其他使用者或未標記的 Paseo home 不接管。既有初始化對話資料會保留，但插件不再建立或開啟它。

## 開發及驗收

```bash
PI_PASEO_SKIP_POSTINSTALL=1 npm ci
npm test
node --test scripts/install-host.test.mjs scripts/bootstrap.test.mjs
npm run typecheck
node scripts/check-package.mjs
node scripts/verify-package-install.mjs
node scripts/verify-host.mjs
npm audit --omit=dev
npm audit --omit=dev --prefix runtime
npm pack --ignore-scripts
```

`host/adapter.patch` 包含 Pi Web 整合原始碼及測試，`host/adapter-meta.json` 包含相容基底與 SHA-256。原始 Pi Web 的完整 checkout、依賴、建置物及本機登入資料都不放入插件發行包。

對話驗收成功以實際 assistant 回覆與新的續聊訊息判定。CLI 存在、模型清單出現或 provider idle 都不能代表可對話。若 Claude 回報 `PROVIDER_QUOTA_EXHAUSTED`，請等待帳號額度恢復或在官方登入入口改用有額度的授權帳號，再重跑驗收。

## 商業部署維護

`health` 輸出不含秘密；只有已安裝、啟用、程序屬於本插件、服務可達且三種 provider 可啟動時才回傳 exit 0。真正對話及 relay 配對另外顯示驗證時間，不能以歷史成功取代目前連線健康。

狀態查詢合併並行請求，provider 狀態探測最多快取 3 秒；每次仍重新核對程序身分。Settings → Agent Connect 開著（分頁可見）時每 5 秒查一次狀態，每次都會讓 Paseo 執行各 provider 的 `--version`。UI 操作期間暫停輪詢，過期狀態不顯示為已就緒。診斷、模型查詢不占用安裝／啟停操作序列。

安裝器使用程序群組時限與 Linux 核心鎖，建置或發布失敗回滾自身變更。更新期間請避免外部同時編輯 launcher；安裝器保留偵測到的外部改動，檔案系統不提供跨外部寫入者的原子 compare-and-swap。程序群組無法涵蓋刻意逃離 session 的程序，部署隔離依賴容器及其資源限制。

從舊的 Git 安裝來源改用不可變版本路徑時，請將原 Pi package 登記替換成新來源，維持一個有效的 Paseo 登記；不同路徑不會被 Pi 自動視為同一套件。先備份 settings，保留原本的停用狀態及初始化對話。Pi 5 此次升級已完成來源替換，舊來源與建置保留供回滾。

反向代理若會清空 `Origin` 或改寫 `Host`，必須在改寫前驗證來源；也需保留並拒絕瀏覽器的 `Sec-Fetch-Site: cross-site`。Pi 5 的入口代理已對 `/api/plugin-paseo` 加入限定正式網址的檢查。部署範例與驗收方式見 [代理來源防護](docs/proxy-origin.md)。

Pi SDK 1.0.0 的內嵌 shrinkwrap 忽略消費者 overrides；安裝階段會以固定官方 `brace-expansion` 5.0.12、`undici` 8.12.3 替換其私有受影響依賴，並由回歸測試驗證 API 相容性。插件自身的 SDK 另將私有 `minimatch` 10.2.6 換成固定的 11.0.1（GHSA-g3hv-75wg-m249）；11.0.1 新增的 `@isaacs/nonrecursive-glob-match` 由發行 lockfile 安裝在上層 `node_modules`，若 SDK 位置載入不到同一版本，修補會在替換前中止並保留原檔。Pi SDK 1.5 起自帶已修補的 `minimatch`，安裝時不更動。Pi Web 主機 adapter 尚未固定 `minimatch`，主機建置內的 SDK 副本不在此替換範圍。請使用發行 lockfile 和安裝流程，避免在使用中的套件目錄執行 `npm install` 或 `npm ci`。

完整驗收紀錄與已知限制見 [驗證紀錄](docs/validation.md)；三品牌、兩台獨立主機及五平台的 Craft Anything 驗收方式見 [功能一致性標準](docs/smart-web-parity.md)。

## 官方參考

實際安裝、三種 provider 對話及 relay 驗證結果見 [驗證紀錄](docs/validation.md)。

- [Paseo 連線方式](https://paseo.sh/docs/connectivity.md)
- [Paseo 自架 Web UI](https://paseo.sh/docs/web-ui.md)
- [Paseo provider 支援](https://paseo.sh/docs/supported-providers.md)
- [Pi Web](https://github.com/agegr/pi-web)

### 手機捲動修正（v0.1.5）

Paseo 設定面板現在位於 Pi Web 的插件設定內容區，沿用該區的垂直捲動；長模型名稱會換行。更新插件後請重建並重新啟動 Pi Web，再重新整理瀏覽器。主機驗證包含手機直向、橫向、桌面，以及展開 60 個模型後的實際觸控／滑鼠捲動回歸測試。

### 同時升級兩個插件

已有舊版 Omnigent／Paseo 的環境，先升級 Omnigent，再安裝對應的 Paseo。固定版本組合不可交叉混用：

```sh
pi install git:github.com/WOOWTECH/pi-omnigent-plugin@v0.3.12
pi install git:github.com/WOOWTECH/pi-paseo-plugin@v0.1.7
```

Paseo 安裝器會交給 Omnigent 建立共用介面；完成後重啟 Pi Web，再到 **設定 → 插件 → Paseo** 配對。收到 `RESTART_REQUIRED` 時，完成重啟後重新整理並驗證三種引擎對話。首次編譯建議預留至少 3 GiB 可用磁碟空間；實測不足 1 GiB 時套件安裝可能因 `ENOSPC` 失敗。官方 Paseo 的主機顯示名稱請在 Paseo App 內修改；插件的「容器備註」僅存於設定頁。

Paseo 安裝器會優先使用已登記在全域設定的 GitHub 版 Omnigent（`git:`、`https://`、`ssh://` 寫法與 `@ref`／`#ref` 皆可），不會再被映像用 `PI_OMNIGENT_PLUGIN_ROOT` 指向的內建舊版拖住而在安裝時失敗；已登記卻找不到或不是 Omnigent 套件時會停止並回報 `OMNIGENT_COORDINATOR_UNAVAILABLE`／`OMNIGENT_COORDINATOR_INVALID`。專案層級（`.pi/settings.json`）的安裝尚未納入此判斷。

**升級映像內建的副本：** Pi Agent 映像把 Omnigent、Paseo 以 `/opt/woow/...` 路徑登記在設定裡。從設定頁或 `pi install` 裝上新版只會「另外多一筆」，不會取代內建項目；重啟時映像啟動腳本挑第一筆同名套件，仍載入內建舊版，Omnigent 設定頁會一直顯示舊版本號。兩個新版都裝好後，請到 **設定 → 插件** 移除 `/opt/woow/pi-omnigent-plugin` 與 `/opt/woow/pi-paseo-plugin` 這兩筆，再重啟 Pi Web。這個流程已在 `pi-agent:20261026.2019`（內建 Omnigent 0.3.21、Paseo 0.1.10）的隔離 Pod 驗證：移除並重啟後，設定頁顯示 Omnigent 0.3.27，Paseo 服務正常，兩者各只剩一筆。

2026-10-26：Pi4 已部署修正版 `/paseo-web`，完成 Claude 串流中重新整理及三引擎續聊驗收，詳見[正式部署報告](docs/pi4-managed-web-2026-10-26.md)。
