import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {privateDirectory,atomicJson,RuntimeError,assertSafePath} from './state.mjs';
import {applyPidLockPatch,pidLockPatchReady,PID_LOCK_PATCH_ID,PID_LOCK_COPIES,PID_LOCK_0112} from './pid-lock-patch.mjs';
import {applyBrandIdentityPatch,brandIdentityPatchReady,BRAND_IDENTITY_PATCH_ID,BRAND_0112} from './brand-identity-patch.mjs';
import {applySmartTasksPatch,smartTasksPatchReady,SMART_TASKS_PATCH_ID} from './smart-tasks-patch.mjs';
export const PASEO_VERSION='0.17.5';
// Managed releases before this one ran either Paseo 0.17.4 or 0.11.2; the pre-release runtimeDir layout used 0.11.2.
export const LEGACY_PASEO_VERSION='0.11.2';
const template=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../runtime');
const lock=fs.readFileSync(path.join(template,'package-lock.json'));
const lockSha256=createHash('sha256').update(lock).digest('hex');
export const RUNTIME_REVISION=PASEO_VERSION+'-r4-'+lockSha256.slice(0,12);
export const runtimeDirectory=loc=>path.join(loc.runtimeDir,'releases',RUNTIME_REVISION);
// Existing-daemon control compatibility only; these releases are never started.
// Frozen 0.11.2 lockfiles: 4cf9d4… shipped with later r3 and all r4 (Agent Connect
// 0.1.18-0.1.23 run 0.11.2-r4-4cf9d40940bf), 6d8dbe… with r2 and the first r3. These four are
// every release Agent Connect 0.1.4-0.1.23 shipped, newest first (0.1.1-0.1.3 ran r1: unsupported).
// r1 and r4 record their revision in state.json on non-Linux hosts; older r2/r3 daemons do not.
const LOCK_0112_HONO='4cf9d40940bf5b58301775cb8322866d3bcd605db341125d98bd5218b0dfefc0';
const LOCK_0112='6d8dbe5154790bbbb0b1281e991871b6f354919022fb55a1235162e969779526';
const LOCK_0174_R1='a651f42711da045b31e8a2b8993d9b82e7b7cbbef0cffcf48dfdcd5baf9d8530';
// Frozen Agent Connect 0.1.24 runtime. It has the original 0.17.4 lock plus PID and brand patches,
// and predates the Smart Tasks integration. These literals only validate its offline control path.
const PID_0174_R1=Object.freeze({original:'a4e8bc790b27c944847b7bb84694b38d0366d08d7d565409edbc63dd6462b8f7',patched:'194013b387417fb9b6d74b7a305173d8f28478ef268b7a4c073b9882af66bd1b',patchId:'1451c9714ffd86380ff04cbe0219b4a2b0d5a3cd39e152fa5e5fabc0d5403828',helperSha256:'37bdef75ee090452ce946bbf051d411352d51fda95d8121ff0c83a34680e3987'});
const BRAND_0174_R1=Object.freeze({original:'bfc79901aa7768a51b98385b6f729dac69a1098f4480a66fd3d2be1d6af06b4b',patched:'17ea88357d2f25caab81ad63d32804fe41158c1d70e8e4f549c4fc7173fe8d68',patchId:'20f860e40bfb9d654182fd996f4f1999f2b73fe2f2f924519bc344a5592e89f2',helperSha256:'036471982ccbbb5a7c3418631518025b245ac50e1c0b1a29c3824d16ba069733'});
// Agent Connect 0.1.25/0.1.26 adds this exact Tasks payload to the same lock and patches.
const TASKS_0174_R2=Object.freeze({registrySha256:'f20ea6c51acf595a72148998547ab6edc8623275f3a36f86eb2dc51415f2098e',provenanceSha256:'08a0cbe942bd3136d983e63f8c723f2b17e21f433d410bddb6faf4b5a1c802c8',patchId:'2250785f3f115705f092c3a0b45ae43386c57ef596a1c9afb65a02a38caeb485'});
const TASKS_0175_R2=Object.freeze({registrySha256:'f20ea6c51acf595a72148998547ab6edc8623275f3a36f86eb2dc51415f2098e',provenanceSha256:'370a20c236583c6d0780d6fa3bdffc6b4723fb0f2f12b612d56fc5a2af3fae95',patchId:'26edef83f851dbba2147fedc49380ebface9abb635c50f421582cb4886a233db'});
const TASKS_0175_R3=Object.freeze({registrySha256:'f20ea6c51acf595a72148998547ab6edc8623275f3a36f86eb2dc51415f2098e',provenanceSha256:'c2041146accbca4096a40d1b13cce9a1337abe9d06c5a04c16b460bb175b9960',patchId:'d126c336c95a2b11a46054694a68edd3cc8028891c347a955532b8b0801a977f'});
// Frozen 0.1.27-rc.2/r3 Tasks payloads remain verifiable for control and rollback.
// Keep r3, r2, rc.1 r1 and legacy descriptors; only the current r4 source is prepared.
const LOCK_0175_R1='8664f2c3f8f58c15b8ec264fec9b69c3bc443192efd60365212e532c811f4ce2';
const BRAND_0175_R1=Object.freeze({original:'a11dd0366089d25c57c71929c3d56d47dfef3d40cc272c010c4e08bc74d9ac19',patched:'4abdd2bc4f72d5865521b0d5adfca0743b6bd3a7cb8729df42f9b0baa635c523',patchId:'54f658b3f7885b521b6d664efbbd22b5f384c1878d36e45bb988de9ce9ac916b',helperSha256:'036471982ccbbb5a7c3418631518025b245ac50e1c0b1a29c3824d16ba069733'});
const priorReleases=[
 {version:'0.17.5',generation:'r3',sha:LOCK_0175_R1,pid:PID_0174_R1,brand:BRAND_0175_R1,tasks:TASKS_0175_R3,recordedRevision:true},
 {version:'0.17.5',generation:'r2',sha:LOCK_0175_R1,pid:PID_0174_R1,brand:BRAND_0175_R1,tasks:TASKS_0175_R2,recordedRevision:true},
 {version:'0.17.5',generation:'r1',sha:LOCK_0175_R1,pid:PID_0174_R1,brand:BRAND_0175_R1,tasks:TASKS_0174_R2,recordedRevision:true},
 {version:'0.17.4',generation:'r2',sha:LOCK_0174_R1,pid:PID_0174_R1,brand:BRAND_0174_R1,tasks:TASKS_0174_R2,recordedRevision:true},
 {version:'0.17.4',generation:'r1',sha:LOCK_0174_R1,pid:PID_0174_R1,brand:BRAND_0174_R1,recordedRevision:true},
 {version:LEGACY_PASEO_VERSION,generation:'r4',sha:LOCK_0112_HONO,pid:PID_LOCK_0112,brand:BRAND_0112,recordedRevision:true},
 {version:LEGACY_PASEO_VERSION,generation:'r3',sha:LOCK_0112_HONO,pid:PID_LOCK_0112},
 {version:LEGACY_PASEO_VERSION,generation:'r3',sha:LOCK_0112,pid:PID_LOCK_0112},
 {version:LEGACY_PASEO_VERSION,generation:'r2',sha:LOCK_0112},
].map(release=>Object.freeze({...release,revision:release.version+'-'+release.generation+'-'+release.sha.slice(0,12)}));
/** Revisions of the earlier releases, newest first. */
export const PRIOR_RUNTIME_REVISIONS=Object.freeze(priorReleases.map(release=>release.revision));
function verifiedPrior(loc,{revision,sha,version,pid,brand,tasks}) {
 // Never follow state-provided paths or scan arbitrary versions.
 const root=path.join(loc.runtimeDir,'releases',revision);
 try {
  const receiptFile=path.join(root,'.pi-paseo-runtime.json');assertSafePath(receiptFile);
  const receipt=JSON.parse(fs.readFileSync(receiptFile));
  if(receipt.revision!==revision||receipt.lockSha256!==sha)return null;
  for(const pkg of ['cli','server']){
   const file=path.join(root,'node_modules/@getpaseo',pkg,'package.json');assertSafePath(file);
   if(JSON.parse(fs.readFileSync(file)).version!==version)return null;
  }
  if(pid){
   if(receipt.pidLockPatchId!==pid.patchId||!pidLockPatchReady(root,pid))return null;
  }else for(const copy of PID_LOCK_COPIES){
   const file=path.join(root,'node_modules/@getpaseo/server',copy,'pid-lock.js');assertSafePath(file);
   if(createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==PID_LOCK_0112.original)return null;
  }
  if(brand&&(receipt.brandIdentityPatchId!==brand.patchId||!brandIdentityPatchReady(root,brand)))return null;
  if(tasks&&(receipt.smartTasksPatchId!==tasks.patchId||!smartTasksPatchReady(root,tasks)))return null;
  return root;
 }catch{return null;} // Unsupported or unsafe releases cannot supply offline control.
}
/** The verified directory of exactly this earlier release, or null. */
export function priorRuntimeDirectory(loc,revision) {
 const release=priorReleases.find(entry=>entry.revision===revision);
 return release?verifiedPrior(loc,release):null;
}
/** The Paseo version of exactly this verified earlier release, or null. */
export function priorRuntimeVersion(loc,revision) {
 const release=priorReleases.find(entry=>entry.revision===revision);
 return release&&verifiedPrior(loc,release)?release.version:null;
}
/** The newest verified earlier release; with `unrecordedOnly`, among those that never recorded their revision. */
export function previousRuntimeDirectory(loc,{unrecordedOnly=false}={}) {
 for(const release of priorReleases){
  if(unrecordedOnly&&release.recordedRevision)continue;
  const root=verifiedPrior(loc,release);if(root)return root;
 }
 return null;
}

export function runtimeReady(loc) {
 try {
  const root=runtimeDirectory(loc);
  assertSafePath(path.join(root,'.pi-paseo-runtime.json'));
  const receipt=JSON.parse(fs.readFileSync(path.join(root,'.pi-paseo-runtime.json')));
  return receipt.lockSha256===lockSha256&&receipt.pidLockPatchId===PID_LOCK_PATCH_ID&&pidLockPatchReady(root)&&receipt.brandIdentityPatchId===BRAND_IDENTITY_PATCH_ID&&brandIdentityPatchReady(root)&&receipt.smartTasksPatchId===SMART_TASKS_PATCH_ID&&smartTasksPatchReady(root)&&JSON.parse(fs.readFileSync(path.join(root,'node_modules/@getpaseo/cli/package.json'))).version===PASEO_VERSION;
 } catch {return false;}
}
export function prepareRuntimeManifest(loc) {
 const root=runtimeDirectory(loc);privateDirectory(root);
 const file=path.join(root,'package.json');assertSafePath(file);
 if(fs.existsSync(file)&&JSON.parse(fs.readFileSync(file)).name!=='pi-paseo-managed-runtime')throw new RuntimeError('RUNTIME_NOT_OWNED');
 for(const name of ['package.json','package-lock.json']) {
  assertSafePath(path.join(root,name));fs.copyFileSync(path.join(template,name),path.join(root,name));
 }
 return root;
}
export function markRuntimeReady(loc) {const root=runtimeDirectory(loc);applyPidLockPatch(root);applyBrandIdentityPatch(root);applySmartTasksPatch(root);atomicJson(path.join(root,'.pi-paseo-runtime.json'),{lockSha256,revision:RUNTIME_REVISION,pidLockPatchId:PID_LOCK_PATCH_ID,brandIdentityPatchId:BRAND_IDENTITY_PATCH_ID,smartTasksPatchId:SMART_TASKS_PATCH_ID});}

// ---- Pruning ----
// Every release is a full install (about 0.6-0.7 GB), and each upgrade leaves the previous one for a rollback and
// for controlling a daemon that still runs it. Pruning removes the ones nothing needs any more.
// It only ever touches a plugin-owned release: a directory directly under <runtimeDir>/releases that is named like
// a revision (<paseo version>-r<n>-<12 hex of its lockfile hash>), is a real directory (never a link) and holds a
// receipt that says the same: .pi-paseo-runtime.json with revision equal to the name and a lockSha256 that begins
// with the name's hash. Anything else under releases/ (other names, plain files, links, half-installed
// directories without a receipt, copies someone else made) and everything outside it, including the legacy
// <runtimeDir>/node_modules that earlier plugin versions installed, stays as it is.
//
// Three steps, so that the slow one never needs the caller's lock: prunePlan reads, claimReleases renames each
// release to .pruning-<revision>-<uuid> (one step: it is no longer a release), removeTombs deletes the tombs. A
// tomb that a crash left behind is a plain leftover: the next plan lists it and the next removal finishes it.
const RELEASE_NAME=/^(\d+)\.(\d+)\.(\d+)-r(\d+)-([0-9a-f]{12})$/;
const TOMB_NAME=/^\.pruning-(\d+\.\d+\.\d+-r\d+-[0-9a-f]{12})-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const RECEIPT='.pi-paseo-runtime.json';
const compareOrder=(a,b)=>{for(let i=0;i<4;i++)if(a[i]!==b[i])return a[i]-b[i];return 0;};
function ownedRelease(releases,name) {
 const match=RELEASE_NAME.exec(name);if(!match)return null;
 const root=path.join(releases,name),receiptFile=path.join(root,RECEIPT);
 let fd;
 try {
  if(!fs.lstatSync(root).isDirectory())return null; // lstat: a link to a directory is not one
  assertSafePath(receiptFile);
  const stat=fs.lstatSync(receiptFile);
  if(!stat.isFile()||stat.size>65536)return null;
  fd=fs.openSync(receiptFile,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);
  const receipt=JSON.parse(fs.readFileSync(fd,'utf8'));
  if(!receipt||typeof receipt!=='object'||receipt.revision!==name)return null;
  if(typeof receipt.lockSha256!=='string'||!/^[0-9a-f]{64}$/.test(receipt.lockSha256)||receipt.lockSha256.slice(0,12)!==match[5])return null;
  return {name,order:match.slice(1,5).map(Number),receiptMtimeMs:stat.mtimeMs};
 } catch {return null;} finally {if(fd!==undefined)try{fs.closeSync(fd);}catch{}}
}
/** The plugin-owned releases under <runtimeDir>/releases, newest first: Paseo version, then revision number, then receipt time
 * (when it was installed), then name for a tie. Releases of one version and revision number differ only in their lockfile hash. */
export function ownedReleases(loc) {
 const releases=path.join(loc.runtimeDir,'releases');
 try {
  assertSafePath(releases);
  if(!fs.lstatSync(releases).isDirectory())return [];
  return fs.readdirSync(releases).map(name=>ownedRelease(releases,name)).filter(Boolean)
   .sort((a,b)=>compareOrder(b.order,a.order)||b.receiptMtimeMs-a.receiptMtimeMs||(a.name<b.name?1:-1));
 } catch {return [];}
}
/** What an earlier removal renamed away and did not finish deleting: [{name: the revision it was, tomb: its directory name}]. */
function leftoverTombs(releases) {
 try {
  return fs.readdirSync(releases).filter(entry=>TOMB_NAME.test(entry)).filter(entry=>{try{return fs.lstatSync(path.join(releases,entry)).isDirectory();}catch{return false;}})
   .map(tomb=>({name:TOMB_NAME.exec(tomb)[1],tomb}));
 } catch {return [];}
}
/** Reads only. {candidates: releases that may go, kept: releases that stay, tombs: leftovers to finish, skipped?: why nothing is planned}.
 * Stay: this release; the one newest earlier release (a rollback); every release newer than this one (a downgrade
 * is followed by an upgrade, and that is 0.7 GB to download again); every name in `keep`, which the caller fills
 * with the releases a running process still uses or needs for control. Without a valid current release nothing is planned.
 * Earlier and newer are positions in ownedReleases' order, not a comparison of version numbers: two releases of one
 * Paseo version and revision number (two lockfiles; r3 shipped with two) tie by number, and the receipt time that orders
 * them in the list decides which is newer and which is the rollback. A tie never makes a release a candidate by itself. */
export function prunePlan(loc,{keep=[]}={}) {
 const releases=path.join(loc.runtimeDir,'releases'),plan={candidates:[],kept:[],tombs:[]};
 try {assertSafePath(releases);if(!fs.lstatSync(releases).isDirectory())return {...plan,skipped:'RELEASES_NOT_A_DIRECTORY'};}
 catch(error) {return error?.code==='ENOENT'?plan:{...plan,skipped:'RELEASES_UNSAFE'};}
 const owned=ownedReleases(loc),index=owned.findIndex(release=>release.name===RUNTIME_REVISION);
 if(index<0)return {...plan,skipped:'CURRENT_RELEASE_NOT_FOUND'};
 const stay=new Set([RUNTIME_REVISION,...keep]);
 if(owned[index+1])stay.add(owned[index+1].name); // the rollback: the release right after this one, newest first
 owned.forEach((release,position)=>(stay.has(release.name)||position<index?plan.kept:plan.candidates).push(release.name));
 plan.tombs=leftoverTombs(releases);
 return plan;
}
/** Renames each named release to a tomb (one step each, no deleting). Cheap: it is the part to do under a lock.
 * {claimed: [{name, tomb}], failed: [names]}. */
export function claimReleases(loc,names) {
 const releases=path.join(loc.runtimeDir,'releases'),claimed=[],failed=[];
 for(const name of names) {
  const tomb=`.pruning-${name}-${randomUUID()}`;
  try {
   if(!ownedRelease(releases,name)||name===RUNTIME_REVISION)throw new RuntimeError('RUNTIME_NOT_OWNED');
   fs.renameSync(path.join(releases,name),path.join(releases,tomb));claimed.push({name,tomb});
  } catch {failed.push(name);}
 }
 return {claimed,failed};
}
// A release is tens of thousands of files. fs.promises.rm({recursive}) starts the delete of every entry of a directory at
// once: all of them are queued on the thread pool, so a read that something else needs (a stop's, a status's) waits behind
// them, and their callbacks keep the event loop busy in long stretches. Measured on a fast disk with 50 000 files: the
// event loop stood still for up to 250 ms and a small readFile took up to 800 ms. removeTree does one operation at a time,
// from the leaves up, pauses briefly every REMOVAL_BATCH operations (the disk is an SD card on the boards this runs on, and a
// daemon is using it), and looks at `aborted` before each operation, so a stop ends it within one.
const PAUSE_MS=2;
/** How many file operations removeTree makes between two pauses (and two turns of the event loop). */
export const REMOVAL_BATCH=64;
/** Deletes `root` and everything under it without following a link: an entry that is a link (or anything but a
 * directory) is unlinked as itself, and only real directories are entered. Resolves to true when the whole tree is gone,
 * to false when `aborted()` ended it first (what is left stays as it is: the directory is still there, with whatever it
 * had not lost yet); anything else that fails is thrown, except ENOENT (someone else already removed it).
 * `ops` is the file system (the fs.promises calls lstat, readdir, unlink and rmdir) and `pause` the wait between batches,
 * for tests. */
export async function removeTree(root,{aborted=()=>false,ops=fs.promises,pause=()=>delay(PAUSE_MS)}={}) {
 let operations=0;
 const batch=async()=>{if(++operations%REMOVAL_BATCH===0)await pause();};
 const gone=error=>error?.code==='ENOENT';
 // The root itself is looked at without following it: a link is removed as itself, whatever it points to.
 try {if(!(await ops.lstat(root)).isDirectory()){await ops.unlink(root);return true;}} catch(error) {if(gone(error))return true;throw error;}
 const stack=[{dir:root,entries:null}];
 while(stack.length) {
  if(aborted())return false;
  const top=stack[stack.length-1];
  if(top.entries===null) {
   // The type of each entry comes with the listing (the directory entry's own type, never what a link points to).
   try {top.entries=await ops.readdir(top.dir,{withFileTypes:true});} catch(error) {if(!gone(error))throw error;stack.pop();}
   await batch();continue;
  }
  const entry=top.entries.pop();
  if(!entry) {
   try {await ops.rmdir(top.dir);} catch(error) {if(!gone(error))throw error;}
   stack.pop();await batch();continue;
  }
  const target=path.join(top.dir,entry.name);
  if(entry.isDirectory()) {stack.push({dir:target,entries:null});continue;}
  try {await ops.unlink(target);} catch(error) {if(!gone(error))throw error;}
  await batch();
 }
 return true;
}
/** Deletes tombs (the slow part: it takes no lock and does not follow links). A tomb is only ever a real directory
 * whose name this code made. {removed: [names], failed: [names], aborted?: true}: with `aborted` the deletion stopped
 * early, and the tomb it was in (and every one after it) is neither removed nor failed, it is left for the next run.
 * `aborted`, `ops` and `pause` go to removeTree. */
export async function removeTombs(loc,items,{aborted=()=>false,ops,pause}={}) {
 const releases=path.join(loc.runtimeDir,'releases'),removed=[],failed=[];
 for(const {name,tomb} of items) {
  if(aborted())return {removed,failed,aborted:true};
  try {
   if(!TOMB_NAME.test(tomb))throw new RuntimeError('RUNTIME_NOT_OWNED');
   if(!fs.lstatSync(path.join(releases,tomb)).isDirectory())throw new RuntimeError('RUNTIME_NOT_OWNED');
   if(await removeTree(path.join(releases,tomb),{aborted,ops,pause})===false)return {removed,failed,aborted:true};
   removed.push(name);
  } catch(error) {(error?.code==='ENOENT'?removed:failed).push(name);} // gone already: someone else finished it
 }
 return {removed,failed};
}
/** All three steps in a row: {removed, kept, failed, skipped?, aborted?}, names only. Best effort: what cannot be removed is
 * reported in `failed`, never thrown. */
export async function pruneRuntimeReleases(loc,{keep=[],aborted,ops,pause}={}) {
 const plan=prunePlan(loc,{keep});
 if(plan.skipped)return {removed:[],kept:[],failed:[],skipped:plan.skipped};
 const claim=claimReleases(loc,plan.candidates),done=await removeTombs(loc,[...plan.tombs,...claim.claimed],{aborted,ops,pause});
 return {removed:done.removed,kept:plan.kept,failed:[...claim.failed,...done.failed],...(done.aborted?{aborted:true}:{})};
}
